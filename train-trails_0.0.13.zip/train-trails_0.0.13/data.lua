
local nyan_sprite = {
  type = "sprite",
  name = "train-trail",
  filename = "__train-trails__/glow.png",
  priority = "high",
  width = 820,
  height = 826,
  scale = 1/10,

}

data:extend({
  nyan_sprite
})
